import { useEffect, useRef, useState } from "react";
import "./FloatingIcon.scss";
import Icon from "./../assets/floatingIcon.svg";

export default function FloatingIcon() {
  const [showIcon, setShowIcon] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [placeholder, setPlaceholder] = useState("");

  const wrapper_Ref = useRef(null);
  const typing_interval_Ref = useRef(null);
  const collapse_timeout_Ref = useRef(null);

  const Typing_Ref = useRef(false);
  const First_Auto_Open_Ref = useRef(true); 

  const sentences = [
    "What are better alternatives at this price?",
    "Tell me which variant makes sense?",
    "What are better alternatives at this price?",
    "Tell me which variant makes sense?"
  ];

  useEffect(() => {
    const t = setTimeout(() => setShowIcon(true), 3000);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!showIcon) return;

    const t = setTimeout(() => {
      open_with_typing(true); 
    }, 5000);

    return () => clearTimeout(t);
  }, [showIcon]);

  const open_with_typing = () => {
  clearAllTimers();
  setIsOpen(true);
  setPlaceholder("");

  let sentenceIndex = 0;
  let charIndex = 0;
  let isDeleting = false;

  const typingSpeed = 80;
  const deletingSpeed = 40;
  const pauseAfterType = 1000;

  const type = () => {
    const currentSentence = sentences[sentenceIndex];

    if (!isDeleting) {

      setPlaceholder(currentSentence.slice(0, charIndex + 1));
      charIndex++;

      if (charIndex === currentSentence.length) {
        setTimeout(() => {
          isDeleting = true;
        }, pauseAfterType);
      }
    } else {
      setPlaceholder(currentSentence.slice(0, charIndex - 1));
      charIndex--;

      if (charIndex === 0) {
        isDeleting = false;
        sentenceIndex++;

        if (sentenceIndex === sentences.length) {
          clearInterval(typing_interval_Ref.current);
          Schedule_Collapse(); 
          return;
        }
      }
    }
  };

  typing_interval_Ref.current = setInterval(
    type,
    isDeleting ? deletingSpeed : typingSpeed
  );
};

  const Schedule_Collapse = () => {
    collapse_timeout_Ref.current = setTimeout(() => {
      if (!Typing_Ref.current) {
        setIsOpen(false);
        setPlaceholder("");

        First_Auto_Open_Ref.current = false;
      }
    }, 100);
  };

  const clearAllTimers = () => {
    clearInterval(typing_interval_Ref.current);
    clearTimeout(collapse_timeout_Ref.current);
  };

  const handleIconClick = () => {
    if (isOpen) {
      clearAllTimers();
      setIsOpen(false);
      setPlaceholder("");
      First_Auto_Open_Ref.current = false;
    } else {
      open_with_typing(false);
    }
  };

  const handleFocus = () => {
    Typing_Ref.current = true;
    clearTimeout(collapse_timeout_Ref.current);
  };

  const handleBlur = () => {
    Typing_Ref.current = false;
    Schedule_Collapse();
  };

  useEffect(() => {
    const outside_Click = (e) => {
      if (
        !isOpen || !wrapper_Ref.current || wrapper_Ref.current.contains(e.target)
      ) return;

      if (First_Auto_Open_Ref.current) 
        return;
      clearAllTimers();
      setIsOpen(false);
      setPlaceholder("");
    };

    document.addEventListener("mousedown", outside_Click);
    return () => document.removeEventListener("mousedown", outside_Click);
  }, [isOpen]);

  if (!showIcon) return null;

  return (
    <div ref={wrapper_Ref} className={`floating_wrapper ${isOpen ? "open" : ""}`} >
        
      <img src={Icon} alt="floating_icon" className="floating_icon" onClick={handleIconClick} />

      <input className="floating_input"
        type="text"
        placeholder={placeholder}   
        onFocus={handleFocus}
        onBlur={handleBlur}
      />
    </div>
  );
}
